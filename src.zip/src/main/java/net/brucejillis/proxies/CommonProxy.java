package net.brucejillis.proxies;

public class CommonProxy {
    public void registerRenderers() {

    }
}
